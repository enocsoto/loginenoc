require('dotenv').config();
const mongoose = require('mongoose');

const dbmongo = () => {
    const DB_URI = process.env.DB_URI;
    mongoose.connect(DB_URI)
        .then(() => { console.log('Conexion exitosa'); })
        .catch((err) => console.error('no se conecto'))
}

module.exports = dbmongo;