const {Router} = require('express');
const { getUser, postUser, getAllUsers, uptadeUser, deleteUser } = require('../controllers/login.controller');
const router = Router();

router.get('/users', getUser);
router.get('/users/:id', getAllUsers);
router.post('/users', postUser);
router.put('/users/:id', uptadeUser);
router.delete('/', deleteUser); 


module.exports= router;