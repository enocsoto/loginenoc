const {model, Schema} = require('mongoose');

const userSchema = Schema({
    name:{
        type: String,
        required: [true, 'El nombre es obligatorio']
    },
    age: {
        type: Number,
        required: [true, 'La edad es requerida']
    },
    email: {
        type: String,
        required: [true, 'El correo es requerido'],
        unique: true
    }
});

module.exports= model('user', userSchema);