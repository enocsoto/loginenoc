const userSchema = require("../models/login");

const postUser = (req, res) => {
  const user = userSchema(req.body);
  // const userss =userSchema(body);
  user
    .save()
    .then((data) => res.json(data))
    .catch((err) => res.json({ msg: "Error al registrar" }));
};

const getUser =(req, res) => {

    userSchema
    .find()
    .then((data) => res.json(data))
    .catch((err) => res.json({ msg: "Error no se encontro registros" }));

};

const getAllUsers =(req, res) => {
    const {id} = req.params;
    userSchema
    .findById(id)
    .then((data) => res.json(data))
    .catch((err) => res.json({ msg: "Error no se encontro registros" }));

};

const uptadeUser =(req, res) => {
    const {id} = req.params;
    const {name, age, email }= req.body;
    userSchema
    .updateOne({_id: id}, {$set:{name, age, email}})
    .then((data) => res.json({ data,
        msg:'Usuario actualizado'
    }))
    .catch((err) => res.json({ msg: `Error no se encontro el usuario con id: ${id}` }));

};

const deleteUser =(req, res) => {
    const {id} = req.params;
    userSchema
    .remove({_id: id})
    .then((data) => res.json({ data,
        msg:'Usuario eliminado'
    }))
    .catch((err) => res.json({ msg: `Error no se encontro el usuario con id: ${id}` }));

};
module.exports = {
  getUser,
  postUser,
  getAllUsers,
  uptadeUser,
  deleteUser
};
